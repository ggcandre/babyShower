// ============================================================================
// Configuração centralizada do frontend
// ============================================================================
// Definir aqui a URL do Web App do Google Apps Script, depois de fazer
// o deployment (ver README.md). Este é o ÚNICO sítio onde a URL deve
// ser definida — tanto o site público (app.js) como o painel de
// administração (admin.js) importam este ficheiro.

window.APP_CONFIG = {
  API_URL: 'URL_DO_GOOGLE_APPS_SCRIPT'
};
